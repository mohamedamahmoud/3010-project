package com.example.myclock;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class AddAlarm extends AppCompatActivity {
    public static final String PREFS = "prefs";
    SharedPreferences.Editor editor ;
    SharedPreferences sp;
    protected String text;
    private EditText hours;
    private EditText mins;
    private Button setAlarm;
    private EditText color;
    private Button AMorPM;
    final String[] colors = {"red", "green", "blue"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_alarm);
        //Enable the button when all the textfields are not empty
        hours = findViewById(R.id.hours);
        hours.setFilters( new InputFilter[]{ new MinMaxFilter( "1" , "12" )});
        mins = findViewById(R.id.mins);
        mins.setFilters( new InputFilter[]{ new MinMaxFilter( "00" , "59" )});
        setAlarm = findViewById(R.id.setAlarm);
        color = findViewById(R.id.color);
        AMorPM = findViewById(R.id.AMorPM);
        //connecting all widget to the textwatcher
        AMorPM.addTextChangedListener(clockTextWatcher);
        //color.addTextChangedListener(clockTextWatcher);
        mins.addTextChangedListener(clockTextWatcher);
        hours.addTextChangedListener(clockTextWatcher);
        AlertDialog.Builder builder = new AlertDialog.Builder(AddAlarm.this);
        builder.setTitle("Select a color for the LED");
        builder.setItems(colors, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if ("red".equals(colors[which])){
                    color.setText("RED");
                }
                else if ("green".equals(colors[which])){
                    color.setText("GREEN");
                }
                else if ("blue".equals(colors[which])){
                    color.setText("BLUE");
                }

            }
        });
        builder.show();
        sendAlarmInfo();
    }
    private void sendAlarmInfo(){
        setAlarm.setOnClickListener(new View.OnClickListener() {
             @Override
            public void onClick(View view) {
                String hourText = hours.getText().toString();
                String minsText = mins.getText().toString();
                String timeText = AMorPM.getText().toString();
                String colorText = color.getText().toString();
                text = hourText + ":" + minsText + " " + timeText + " " + colorText;
                Intent intent = new Intent(view.getContext(), SetAlarm.class);
                 sp = getSharedPreferences(PREFS, 0);
                 editor = sp.edit();
                 editor.putString("myText", text);
                 editor.apply();
               //  intent.putExtra("mytext", text);
                 startActivityForResult(intent, 0);

             }
        });
    }
    private TextWatcher clockTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String hourInput = hours.getText().toString().trim();
            String minInput = mins.getText().toString().trim();
            String colorInput = color.getText().toString().trim();
            String time2 = AMorPM.getText().toString().trim();
            setAlarm.setEnabled(! time2.isEmpty() && !colorInput.isEmpty() && !minInput.isEmpty() && !hourInput.isEmpty());

        }
        @Override
        public void afterTextChanged(Editable s) {
        }
    };
}
