package com.example.myclock;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SetAlarm extends AppCompatActivity {
    private ProgressDialog pDialog;
    JSONParser jsonParser = new JSONParser();

    public static final String PREFS = "prefs";
    private Switch sw1,sw2;
    private Button delete1, delete2;
    public TextView t1,t2;
    private String copyText;
    private SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_alarm);
        //first alarm
        t1 = findViewById(R.id.textView1);
        delete1 = findViewById(R.id.delete1);
        sw1 = findViewById(R.id.switch1);
        //second alarm
        t2 = findViewById(R.id.textView2);
        delete2 = findViewById(R.id.delete2);
        sw2 = findViewById(R.id.switch2);
        // if there are no alarms. Set alarm No 1
        //copyText = getIntent().getStringExtra("mytext");
        sp = getSharedPreferences(PREFS,0);
        if(delete1.getVisibility() == View.INVISIBLE) {
            t1.setText(sp.getString("myText", ""));
        }

        if(sw1.isChecked()){

            new Create_Part().execute();
        }

        if (!t1.getText().toString().isEmpty()) {
            sw1.setVisibility(View.VISIBLE);
            sw1.setChecked(true);
            delete1.setVisibility(View.VISIBLE);
        }
        delete1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sw1.setVisibility(View.INVISIBLE);
                t1.setText("");
                delete1.setVisibility(View.INVISIBLE);
                sp.edit().remove("myText").apply();
            }
        });

    }
    public void AaddAlarm(View view) {
        Intent intent = new Intent(this,AddAlarm.class);
        startActivity(intent);
    }

    class Create_Part extends AsyncTask<String,String,String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(SetAlarm.this);
            pDialog.setMessage("Sending part to the database..."); //Set the message for the loading window
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show(); //Place the loading message on the screen
        }

        @Override

        protected String doInBackground(String... args) {

            @SuppressLint("WrongThread") String String_name = t1.getText().toString(); //Get the inserted text from the editText files

            List params = new ArrayList<>();
            params.add(new BasicNameValuePair("Name", String_name)); //Add the parameters to an array

// Do the HTTP POST Request with the JSON parameters
// Change "RaspberryPi_IP to your home IP address or Noip service
            JSONObject json = jsonParser.makeHttpRequest("RaspberryPi_IP/db_create.php", "POST", params);
            try {

                int success = json.getInt("success");
                if(success == 1){
                    finish();

                }

            } catch (JSONException e) {

                e.printStackTrace();

            }

            return null;

        }



    }
}
